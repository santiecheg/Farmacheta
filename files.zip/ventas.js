/* Lógica de ventas: alta, validación con reintentos, preventa, pago y anulación */
Store.renderNav('ventas');
const $ = id => document.getElementById(id);
let items = [], editId = null;
const timers = {}; // temporizadores de validación por venta

function aviso(texto, tipo) { $('msg').className = 'aviso ' + tipo; $('msg').textContent = texto; }
const getVenta = id => Store.getAll('ventas').find(v => v.id === id);
const getMed = id => Store.getAll('medicamentos').find(m => m.id === id);
const totalDe = lista => lista.reduce((s, i) => s + i.cantidad * i.precioUnitario, 0);

/* ---------- Formulario ---------- */
function llenarSelect() {
  $('selMed').innerHTML = Store.getAll('medicamentos').map(m => `<option value="${m.id}">${Store.esc(m.nombre)} (stock ${m.stock})</option>`).join('');
}
function agregarItem() {
  const m = getMed(+$('selMed').value), cant = +$('cantidad').value;
  if (!m || cant < 1) return;
  const ex = items.find(i => i.medicamentoId === m.id);
  if (ex) ex.cantidad += cant; else items.push({ medicamentoId: m.id, nombre: m.nombre, cantidad: cant, precioUnitario: m.precio });
  renderItems();
}
function quitarItem(n) { items.splice(n, 1); renderItems(); }
function renderItems() {
  $('listaItems').innerHTML = items.map((i, n) => `<li>${Store.esc(i.nombre)} × ${i.cantidad} — ${Store.formatMoney(i.cantidad * i.precioUnitario)}
    <button type="button" class="btn-sm sec" onclick="quitarItem(${n})">Quitar</button></li>`).join('');
  $('totalItems').textContent = Store.formatMoney(totalDe(items));
}
function limpiarForm() { $('form').reset(); items = []; editId = null; renderItems(); $('btnGuardar').textContent = 'Guardar atención'; }
function guardarVenta(e) {
  e.preventDefault();
  if (!items.length) return aviso('Agregá al menos un medicamento.', 'err');
  const datos = { paciente: $('paciente').value, dni: $('dni').value, obraSocial: $('obraSocial').value,
    numeroReceta: $('receta').value, items: [...items], total: totalDe(items) };
  if (editId) Store.update('ventas', editId, { ...datos, estadoValidacion: 'pendiente' });
  else Store.add('ventas', { ...datos, numero: 'V-' + String(Store.nextId(Store.getAll('ventas'))).padStart(4, '0'),
    fecha: Store.hoy(), estadoValidacion: 'pendiente', estadoVenta: 'en_proceso' });
  limpiarForm(); aviso('Atención guardada (en proceso, validación pendiente).', 'ok'); renderTabla();
}

/* ---------- Stock ---------- */
function hayStock(v) { return v.items.every(i => { const m = getMed(i.medicamentoId); return m && m.stock >= i.cantidad; }); }
function cancelarPorStock(v) {
  Store.update('ventas', v.id, { estadoVenta: 'anulada' });
  aviso('Sin stock — proceso cancelado', 'err'); renderTabla();
}
function moverStock(v, signo) { // signo -1 descuenta, +1 devuelve
  v.items.forEach(i => { const m = getMed(i.medicamentoId); if (m) Store.update('medicamentos', m.id,
    { stock: m.stock + signo * i.cantidad, vendidosHistoricos: Math.max(0, m.vendidosHistoricos - signo * i.cantidad) }); });
}

/* ---------- Validación ---------- */
function validarOnline(id, intento = 0) {
  const v = getVenta(id);
  if (!v || v.estadoVenta !== 'en_proceso' || v.estadoValidacion !== 'pendiente') return;
  if (!hayStock(v)) return cancelarPorStock(v);
  aviso(`Validando online (${v.numero})…`, 'info');
  timers[id] = setTimeout(() => {
    const r = Math.random();
    if (r < 0.7) { Store.update('ventas', id, { estadoValidacion: 'autorizada_online' }); aviso('Autorizada online ✔', 'ok'); }
    else if (r < 0.94) { // servicio caído: reintentos automáticos
      if (intento < 3) {
        aviso(`Servicio caído. Reintento automático ${intento + 1}/3 en 5 s… (podés usar "Autorizar manual")`, 'warn');
        timers[id] = setTimeout(() => validarOnline(id, intento + 1), 5000);
      } else aviso('Reintentos agotados. Usá "Autorizar manual".', 'err');
    } else { Store.update('ventas', id, { estadoValidacion: 'rechazada', estadoVenta: 'anulada' }); aviso('Receta rechazada. Proceso cortado.', 'err'); }
    renderTabla();
  }, 1500);
}
function autorizarManual(id) {
  clearTimeout(timers[id]);
  Store.update('ventas', id, { estadoValidacion: 'autorizada_manual' });
  aviso('Autorizada manualmente por el farmacéutico.', 'ok'); renderTabla();
}

/* ---------- Preventa, pago, anulación ---------- */
function emitirPreventa(id) {
  const v = getVenta(id);
  if (!v.estadoValidacion.startsWith('autorizada')) return aviso('Falta validación autorizada.', 'err');
  if (!hayStock(v)) return cancelarPorStock(v);
  Store.update('ventas', id, { estadoVenta: 'preventa' }); renderTabla(); verTicket(id, 'Ticket de preventa');
}
function registrarPago(id) {
  const v = getVenta(id);
  if (!hayStock(v)) return cancelarPorStock(v);
  moverStock(v, -1); Store.update('ventas', id, { estadoVenta: 'pagada' });
  aviso('Pago registrado. Stock descontado.', 'ok'); renderTabla(); verTicket(id, 'Comprobante de pago');
}
function anular(id) {
  const v = getVenta(id);
  if (!confirm('¿Anular la venta ' + v.numero + '?')) return;
  clearTimeout(timers[id]);
  if (v.estadoVenta === 'pagada') moverStock(v, +1); // devuelve stock
  Store.update('ventas', id, { estadoVenta: 'anulada' }); aviso('Venta anulada.', 'warn'); renderTabla();
}
function modificar(id) {
  const v = getVenta(id);
  if (v.estadoVenta !== 'en_proceso') return aviso('Solo se pueden modificar ventas en proceso.', 'err');
  editId = id; items = v.items.map(i => ({ ...i }));
  $('paciente').value = v.paciente; $('dni').value = v.dni; $('obraSocial').value = v.obraSocial; $('receta').value = v.numeroReceta;
  $('btnGuardar').textContent = 'Guardar cambios'; renderItems(); window.scrollTo(0, 0);
}
function verTicket(id, titulo = 'Detalle de venta') {
  const v = getVenta(id);
  $('ticket').innerHTML = `<div class="ticket"><h3>${titulo} ${v.numero}</h3>
    <p>${v.fecha} · ${Store.esc(v.paciente)} (DNI ${Store.esc(v.dni)}) · ${Store.esc(v.obraSocial)} · Receta ${Store.esc(v.numeroReceta)}</p>
    <ul class="items">${v.items.map(i => `<li>${Store.esc(i.nombre)} × ${i.cantidad} — ${Store.formatMoney(i.cantidad * i.precioUnitario)}</li>`).join('')}</ul>
    <b>Total: ${Store.formatMoney(v.total)}</b><p>Validación: ${v.estadoValidacion} · Estado: ${v.estadoVenta}</p></div>`;
}

/* ---------- Tablas ---------- */
function acciones(v) {
  const b = (txt, fn, cls = '') => `<button class="btn-sm ${cls}" onclick="${fn}(${v.id})">${txt}</button>`;
  let a = b('Ver', 'verTicket', 'sec');
  if (v.estadoVenta === 'en_proceso') {
    if (v.estadoValidacion === 'pendiente') a += b('Validar online', 'validarOnline') + b('Autorizar manual', 'autorizarManual', 'sec');
    else a += b('Emitir ticket de preventa', 'emitirPreventa');
    a += b('Modificar', 'modificar', 'sec');
  }
  if (v.estadoVenta === 'preventa') a += b('Registrar pago', 'registrarPago');
  if (v.estadoVenta !== 'anulada') a += b('Anular', 'anular', 'peligro');
  return a;
}
function renderTabla() {
  llenarSelect();
  $('tabla').innerHTML = Store.getAll('ventas').slice().reverse().map(v => `<tr><td>${v.numero}</td><td>${v.fecha}</td>
    <td>${Store.esc(v.paciente)}</td><td>${Store.formatMoney(v.total)}</td>
    <td><span class="badge info">${v.estadoValidacion}</span></td><td><span class="badge ${v.estadoVenta === 'anulada' ? 'err' : v.estadoVenta === 'pagada' ? 'ok' : 'warn'}">${v.estadoVenta}</span></td>
    <td>${acciones(v)}</td></tr>`).join('');
}
function toggleListado() {
  const d = $('listado');
  d.innerHTML = d.innerHTML ? '' : '<table><tr><th>Medicamento</th><th>Droga</th><th>Presentación</th><th>Precio</th><th>Stock</th></tr>' +
    Store.getAll('medicamentos').map(m => `<tr><td>${Store.esc(m.nombre)}</td><td>${Store.esc(m.droga)}</td><td>${Store.esc(m.presentacion)}</td><td>${Store.formatMoney(m.precio)}</td><td>${m.stock}</td></tr>`).join('') + '</table>';
}
$('form').addEventListener('submit', guardarVenta);
renderTabla(); renderItems();
